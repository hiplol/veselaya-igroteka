# -*- coding: utf-8 -*-
"""
Весёлая Игротека — Duolingo-style
Адаптировано для запуска в браузере через Pygbag.
"""
import pygame, random, sys, os, json, math, asyncio

# ================= ИНИЦИАЛИЗАЦИЯ И ЗВУК =================
try:
    pygame.mixer.pre_init(frequency=44100, size=-16, channels=2, buffer=512)
    pygame.init()
    pygame.mixer.init()
except Exception as e:
    print("Ошибка инициализации звука/микшера:", e)

pygame.font.init()

try:
    import numpy as np

    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

MIXER_OK = pygame.mixer.get_init() is not None


def make_tone(freq, dur, vol=0.25, kind="sine"):
    if not (MIXER_OK and HAS_NUMPY):
        return None
    try:
        import pygame.sndarray as snd
        sr = pygame.mixer.get_init()[0]
        n = int(sr * dur)
        t = np.arange(n) / sr
        if kind == "sine":
            wave = np.sin(2 * np.pi * freq * t)
        elif kind == "square":
            wave = np.sign(np.sin(2 * np.pi * freq * t))
        elif kind == "tri":
            wave = 2 * np.abs(2 * (t * freq - np.floor(t * freq + 0.5))) - 1
        else:
            wave = np.sin(2 * np.pi * freq * t)
        env = np.ones(n)
        a = max(1, int(n * 0.04))
        r = max(1, int(n * 0.35))
        env[:a] = np.linspace(0, 1, a)
        env[-r:] = np.linspace(1, 0, r)
        wave = (wave * env * vol * 32767).astype(np.int16)
        stereo = np.column_stack([wave, wave])
        return snd.make_sound(stereo)
    except Exception:
        return None


SOUNDS = {}
if MIXER_OK and HAS_NUMPY:
    try:
        SOUNDS["correct"] = make_tone(880, 0.15, 0.30)
        SOUNDS["wrong"] = make_tone(160, 0.32, 0.30, "square")
        SOUNDS["click"] = make_tone(620, 0.05, 0.15)
        SOUNDS["win"] = make_tone(1046, 0.55, 0.35)
        SOUNDS["back"] = make_tone(320, 0.08, 0.15)
        SOUNDS["achieve"] = make_tone(1320, 0.35, 0.30)
        SOUNDS["combo"] = make_tone(1200, 0.20, 0.28)
    except Exception:
        SOUNDS = {}

# ================= ОКНО =================
W, H = 1000, 800
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption("Весёлая Игротека")
clock = pygame.time.Clock()

# ================= ШРИФТЫ =================
FONT_PATH = pygame.font.match_font('arial,dejavusans,liberationsans,verdana,tahoma,segoeui')
_fc = {}


def font(size, bold=False):
    k = (size, bold)
    if k not in _fc:
        f = pygame.font.Font(FONT_PATH, size) if FONT_PATH else pygame.font.SysFont(None, size)
        f.set_bold(bold)
        _fc[k] = f
    return _fc[k]


# ================= ЦВЕТА =================
BG = (250, 246, 238)
DARK = (55, 55, 75)
WHITE = (255, 255, 255)
RED = (235, 90, 90)
GREEN = (105, 195, 115)
BLUE = (95, 155, 235)
YELLOW = (250, 200, 80)
PURPLE = (175, 140, 225)
ORANGE = (250, 165, 85)
PINK = (245, 145, 175)
TEAL = (85, 200, 195)
GRAY = (215, 215, 225)
GOLD = (255, 210, 60)
FIRE = (255, 130, 60)


def darker(c, d=45):
    return tuple(max(0, v - d) for v in c)


def lighter(c, d=30):
    return tuple(min(255, v + d) for v in c)


# ================= ХЕЛПЕРЫ =================
def draw_text(text, size, color, center, bold=False):
    s = font(size, bold).render(str(text), True, color)
    r = s.get_rect(center=center)
    screen.blit(s, r)
    return r


def draw_button(rect, color, text="", text_color=WHITE, size=34):
    pygame.draw.rect(screen, darker(color), rect.move(0, 6), border_radius=18)
    pygame.draw.rect(screen, color, rect, border_radius=18)
    if text:
        draw_text(text, size, text_color, rect.center, bold=True)


def star_points(cx, cy, outer, inner, n=5, rot=-math.pi / 2):
    pts = []
    for i in range(2 * n):
        r = outer if i % 2 == 0 else inner
        a = rot + i * math.pi / n
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def draw_star(cx, cy, r, color, filled=True):
    pts = star_points(cx, cy, r, r * 0.45)
    if filled:
        pygame.draw.polygon(screen, color, pts)
        pygame.draw.polygon(screen, darker(color, 60), pts, 3)
    else:
        pygame.draw.polygon(screen, GRAY, pts, 3)


def draw_shape(surf, shape, color, rect, width=0):
    cx, cy = rect.center
    r = min(rect.w, rect.h) // 2
    if r < 4:
        return
    if shape == "circle":
        pygame.draw.circle(surf, color, (cx, cy), r, width)
    elif shape == "square":
        pygame.draw.rect(surf, color, pygame.Rect(cx - r, cy - r, 2 * r, 2 * r),
                         width, border_radius=max(4, r // 5))
    elif shape == "triangle":
        pygame.draw.polygon(surf, color, [(cx, cy - r),
                                          (cx - int(r * 0.95), cy + int(r * 0.8)),
                                          (cx + int(r * 0.95), cy + int(r * 0.8))], width)
    elif shape == "diamond":
        pygame.draw.polygon(surf, color, [(cx, cy - r), (cx + r, cy),
                                          (cx, cy + r), (cx - r, cy)], width)
    elif shape == "star":
        pygame.draw.polygon(surf, color, star_points(cx, cy, r, int(r * 0.45)), width)
    elif shape == "heart":
        rr = max(3, int(r * 0.55))
        pygame.draw.circle(surf, color, (cx - rr, cy - rr // 2), rr)
        pygame.draw.circle(surf, color, (cx + rr, cy - rr // 2), rr)
        pygame.draw.polygon(surf, color, [(cx - 2 * rr, cy - rr // 4),
                                          (cx + 2 * rr, cy - rr // 4),
                                          (cx, cy + r)])


def draw_check(cx, cy, s=40, color=GREEN):
    pygame.draw.lines(screen, color, False,
                      [(cx - s, cy), (cx - s * 0.3, cy + s * 0.7), (cx + s, cy - s * 0.7)], 12)


def draw_cross(cx, cy, s=35, color=RED):
    pygame.draw.line(screen, color, (cx - s, cy - s), (cx + s, cy + s), 12)
    pygame.draw.line(screen, color, (cx + s, cy - s), (cx - s, cy + s), 12)


def draw_lock(cx, cy, s=16):
    pygame.draw.rect(screen, (150, 150, 165), (cx - s, cy - s // 2, 2 * s, int(1.5 * s)), border_radius=4)
    pygame.draw.arc(screen, (150, 150, 165),
                    (cx - int(s * 0.7), cy - int(s * 1.6), int(1.4 * s), int(1.6 * s)),
                    0, math.pi, 5)


def draw_medal(cx, cy, r=18):
    pygame.draw.circle(screen, GOLD, (cx, cy), r)
    pygame.draw.circle(screen, darker(GOLD, 60), (cx, cy), r, 3)
    draw_text("★", int(r * 1.3), darker(GOLD, 80), (cx, cy + 1), bold=True)


def draw_progress_bar(rect, ratio, color):
    pygame.draw.rect(screen, GRAY, rect, border_radius=rect.h // 2)
    if ratio > 0:
        fill = pygame.Rect(rect.x, rect.y, int(rect.w * ratio), rect.h)
        pygame.draw.rect(screen, color, fill, border_radius=rect.h // 2)


def draw_flame(cx, cy, size, color=FIRE):
    pts = [
        (cx, cy - size),
        (cx - size * 0.7, cy + size * 0.2),
        (cx - size * 0.3, cy + size * 0.5),
        (cx - size * 0.5, cy + size),
        (cx + size * 0.5, cy + size),
        (cx + size * 0.3, cy + size * 0.4),
        (cx + size * 0.7, cy),
    ]
    pygame.draw.polygon(screen, color, pts)
    inner = [
        (cx, cy - size * 0.4),
        (cx - size * 0.3, cy + size * 0.4),
        (cx + size * 0.3, cy + size * 0.4),
    ]
    pygame.draw.polygon(screen, YELLOW, inner)


# ================= СОХРАНЕНИЕ (ДЛЯ WEB) =================
SAVE_FILE = "progress.json"


def load_progress():
    if os.path.exists(SAVE_FILE):
        try:
            with open(SAVE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_progress(p):
    try:
        with open(SAVE_FILE, "w", encoding="utf-8") as f:
            json.dump(p, f, ensure_ascii=False)
    except Exception:
        pass


progress = load_progress()

# ================= КОНСТАНТЫ =================
GAMES = [
    {"id": "math", "title": "Счёт до 10", "sub": "Реши примеры", "color": BLUE, "concept": "примеры"},
    {"id": "dictation", "title": "Графический диктант", "sub": "Повтори путь", "color": GREEN, "concept": "клетки"},
    {"id": "pattern", "title": "Продолжи узор", "sub": "Найди следующую", "color": ORANGE, "concept": "узор"},
    {"id": "symmetry", "title": "Симметрия", "sub": "Дорисуй половину", "color": PINK, "concept": "симметрия"},
    {"id": "words", "title": "Словесные игры", "sub": "Вставь букву", "color": PURPLE, "concept": "слова"},
    {"id": "maze", "title": "Лабиринт", "sub": "Найди выход", "color": TEAL, "concept": "лабиринт"},
]

DIFFICULTIES = [
    {"id": "easy", "name": "Легко", "color": GREEN},
    {"id": "normal", "name": "Средне", "color": BLUE},
    {"id": "hard", "name": "Сложно", "color": RED},
]

SHAPES = ["circle", "square", "triangle", "star", "diamond", "heart"]
SHAPE_COLORS = [RED, GREEN, BLUE, YELLOW, PURPLE, ORANGE, PINK, TEAL,
                (140, 200, 255), (200, 150, 100)]


def migrate_progress():
    for g in GAMES:
        gid = g["id"]
        if gid in progress and isinstance(progress[gid], dict):
            keys = list(progress[gid].keys())
            if keys and all(k.isdigit() for k in keys):
                old = progress[gid]
                progress[gid] = {"stars": old, "difficulty": "normal"}
        elif gid not in progress:
            progress[gid] = {"stars": {}, "difficulty": "normal"}
    progress.setdefault("settings", {"sound": True})
    progress.setdefault("achievements", {})
    progress.setdefault("stats", {})


migrate_progress()

ACHIEVEMENTS = [
    {"id": "first_step", "title": "Первые шаги", "desc": "Пройди первый уровень"},
    {"id": "no_mistakes", "title": "Без ошибок", "desc": "Уровень на 3 звезды"},
    {"id": "perfect_5", "title": "Отличник", "desc": "5 уровней на 3 звезды"},
    {"id": "perfect_10", "title": "Суперотличник", "desc": "10 уровней на 3 звезды"},
    {"id": "stars_15", "title": "Звёздный охотник", "desc": "Собери 15 звёзд"},
    {"id": "stars_40", "title": "Звёздный мастер", "desc": "Собери 40 звёзд"},
    {"id": "stars_100", "title": "Звёздный король", "desc": "Собери 100 звёзд"},
    {"id": "all_games", "title": "Исследователь", "desc": "Пройди уровень в каждой игре"},
    {"id": "combo_10", "title": "Серия из 10", "desc": "10 правильных подряд"},
    {"id": "combo_20", "title": "Серия из 20", "desc": "20 правильных подряд"},
    {"id": "hard_level", "title": "Смельчак", "desc": "Пройди уровень на сложном"},
    {"id": "math_20", "title": "Мастер счёта", "desc": "20 уровней в «Счёт»"},
    {"id": "dictation_10", "title": "Клеточный мастер", "desc": "10 уровней в диктанте"},
    {"id": "pattern_10", "title": "Узорщик", "desc": "10 уровней в узорах"},
    {"id": "symmetry_10", "title": "Зеркало", "desc": "10 уровней в симметрии"},
    {"id": "words_10", "title": "Знаток слов", "desc": "10 уровней в словах"},
    {"id": "maze_10", "title": "Путешественник", "desc": "10 уровней в лабиринте"},
]


def get_difficulty(gid):
    return progress.get(gid, {}).get("difficulty", "normal")


def set_difficulty(gid, diff):
    progress.setdefault(gid, {"stars": {}, "difficulty": "normal"})["difficulty"] = diff
    save_progress(progress)


def level_stars(gid, lvl):
    stars = progress.get(gid, {}).get("stars", {})
    return stars.get(str(lvl), 0) if isinstance(stars, dict) else 0


def level_unlocked(gid, lvl):
    if lvl == 1:
        return True
    return level_stars(gid, lvl - 1) > 0


def current_level(gid):
    stars = progress.get(gid, {}).get("stars", {})
    if not isinstance(stars, dict):
        return 1
    i = 1
    while str(i) in stars:
        i += 1
    return i


def game_stars(gid):
    stars = progress.get(gid, {}).get("stars", {})
    return sum(stars.values()) if isinstance(stars, dict) else 0


def total_stars():
    return sum(game_stars(g["id"]) for g in GAMES)


def check_achievements():
    p = progress.setdefault("achievements", {})
    new_ones = []

    def unlock(aid):
        if not p.get(aid):
            p[aid] = True
            new_ones.append(aid)

    games = [g["id"] for g in GAMES]
    if any(game_stars(g) > 0 for g in games):
        unlock("first_step")
    perfect = sum(1 for g in games
                  for v in progress.get(g, {}).get("stars", {}).values() if v == 3)
    if perfect >= 1:
        unlock("no_mistakes")
    if perfect >= 5:
        unlock("perfect_5")
    if perfect >= 10:
        unlock("perfect_10")
    ts = total_stars()
    if ts >= 15:
        unlock("stars_15")
    if ts >= 40:
        unlock("stars_40")
    if ts >= 100:
        unlock("stars_100")
    if all(game_stars(g) > 0 for g in games):
        unlock("all_games")
    if progress.get("stats", {}).get("best_streak", 0) >= 10:
        unlock("combo_10")
    if progress.get("stats", {}).get("best_streak", 0) >= 20:
        unlock("combo_20")
    if progress.get("stats", {}).get("hard_wins", 0) >= 1:
        unlock("hard_level")
    if len(progress.get("math", {}).get("stars", {})) >= 20:
        unlock("math_20")
    for gid, aid in [("dictation", "dictation_10"), ("pattern", "pattern_10"),
                     ("symmetry", "symmetry_10"), ("words", "words_10"), ("maze", "maze_10")]:
        if len(progress.get(gid, {}).get("stars", {})) >= 10:
            unlock(aid)

    if new_ones:
        save_progress(progress)
        for aid in new_ones:
            a = next((a for a in ACHIEVEMENTS if a["id"] == aid), None)
            if a:
                show_toast("🏆 " + a["title"], GOLD)
        play("achieve")
    return new_ones


def play(name):
    if not progress.get("settings", {}).get("sound", True):
        return
    snd = SOUNDS.get(name)
    if snd:
        try:
            snd.play()
        except Exception:
            pass


toast = {"text": "", "until": 0, "color": YELLOW}


def show_toast(text, color=YELLOW):
    toast["text"] = text
    toast["until"] = pygame.time.get_ticks() + 2800
    toast["color"] = color


def draw_toast(now):
    if now < toast["until"] and toast["text"]:
        r = pygame.Rect(0, 0, 560, 60)
        r.center = (W // 2, 30)
        pygame.draw.rect(screen, darker(toast["color"], 40), r.move(0, 4), border_radius=14)
        pygame.draw.rect(screen, toast["color"], r, border_radius=14)
        draw_text(toast["text"], 24, DARK, r.center, bold=True)


particles = []


def burst(x, y, color, n=20, spread=6):
    for _ in range(n):
        a = random.uniform(0, 2 * math.pi)
        v = random.uniform(2, spread)
        particles.append({
            "x": x, "y": y,
            "vx": math.cos(a) * v, "vy": math.sin(a) * v - 2,
            "life": 1.0, "color": color,
            "size": random.randint(3, 8),
            "rot": random.uniform(0, 6),
            "vr": random.uniform(-0.2, 0.2),
        })


def update_particles():
    for p in particles:
        p["x"] += p["vx"]
        p["y"] += p["vy"]
        p["vy"] += 0.35
        p["vx"] *= 0.98
        p["life"] -= 0.025
        p["rot"] += p["vr"]
    particles[:] = [p for p in particles if p["life"] > 0]


def draw_particles():
    for p in particles:
        sz = int(p["size"] * p["life"])
        if sz < 1:
            continue
        c = p["color"]
        fade = tuple(int(v * (0.4 + 0.6 * p["life"])) for v in c)
        pygame.draw.circle(screen, fade, (int(p["x"]), int(p["y"])), sz)


shake = {"mag": 0.0}


def screen_shake(power=10):
    shake["mag"] = max(shake["mag"], power)


def apply_shake():
    if shake["mag"] > 1.0:
        temp = screen.copy()
        screen.fill(BG)
        m = int(shake["mag"])
        ox = random.randint(-m, m)
        oy = random.randint(-m, m)
        screen.blit(temp, (ox, oy))
        shake["mag"] *= 0.82
    else:
        shake["mag"] = 0.0


class Mascot:
    def __init__(self):
        self.mood = "idle"
        self.mood_until = 0
        self.bounce = 0
        self.wobble = 0

    def set_mood(self, mood, dur=800):
        self.mood = mood
        self.mood_until = pygame.time.get_ticks() + dur
        if mood == "happy":
            self.bounce = 8

    def update(self, now):
        if now > self.mood_until:
            self.mood = "idle"
        if self.bounce > 0:
            self.bounce = max(0, self.bounce - 0.6)
        self.wobble = math.sin(now * 0.004) * 3

    def draw(self, cx, cy, r, now):
        mood = self.mood
        cy = cy - self.bounce + self.wobble
        body_col = TEAL
        pygame.draw.circle(screen, darker(body_col, 40), (cx, cy + 3), r)
        pygame.draw.circle(screen, body_col, (cx, cy), r)
        for i in range(3):
            a = -math.pi / 2 + (i - 1) * 0.5
            ex = cx + int(r * 0.85 * math.cos(a))
            ey = cy + int(r * 0.85 * math.sin(a))
            pygame.draw.circle(screen, body_col, (ex, ey), int(r * 0.22))
        pygame.draw.circle(screen, PINK, (cx - r // 2, cy + r // 4), r // 6)
        pygame.draw.circle(screen, PINK, (cx + r // 2, cy + r // 4), r // 6)
        ey = cy - r // 4
        if mood == "happy":
            pygame.draw.arc(screen, WHITE, (cx - int(r * 0.6), ey - int(r * 0.25), int(r * 0.5), int(r * 0.5)), 0,
                            math.pi, 4)
            pygame.draw.arc(screen, WHITE, (cx + int(r * 0.1), ey - int(r * 0.25), int(r * 0.5), int(r * 0.5)), 0,
                            math.pi, 4)
            pygame.draw.arc(screen, WHITE, (cx - int(r * 0.35), cy, int(r * 0.7), int(r * 0.5)), math.pi, 2 * math.pi,
                            4)
        elif mood == "sad":
            pygame.draw.arc(screen, WHITE, (cx - int(r * 0.6), ey - int(r * 0.1), int(r * 0.5), int(r * 0.5)), math.pi,
                            2 * math.pi, 4)
            pygame.draw.arc(screen, WHITE, (cx + int(r * 0.1), ey - int(r * 0.1), int(r * 0.5), int(r * 0.5)), math.pi,
                            2 * math.pi, 4)
            pygame.draw.arc(screen, WHITE, (cx - int(r * 0.35), cy + r // 4, int(r * 0.7), int(r * 0.4)), 0, math.pi, 4)
        else:
            pygame.draw.circle(screen, WHITE, (cx - int(r * 0.35), ey), int(r * 0.16))
            pygame.draw.circle(screen, WHITE, (cx + int(r * 0.35), ey), int(r * 0.16))
            pygame.draw.arc(screen, WHITE, (cx - int(r * 0.35), cy - int(r * 0.05), int(r * 0.7), int(r * 0.45)),
                            math.pi, 2 * math.pi, 4)


mascot = Mascot()

streak = {
    "count": 0,
    "best": progress.get("stats", {}).get("best_streak", 0),
    "show_until": 0,
    "combo_msg": "",
    "combo_until": 0,
}


def register_correct():
    streak["count"] += 1
    if streak["count"] > streak["best"]:
        streak["best"] = streak["count"]
        progress.setdefault("stats", {})["best_streak"] = streak["best"]
    if streak["count"] in (3, 5, 10, 15, 20, 30):
        streak["combo_msg"] = "Серия: %d!" % streak["count"]
        streak["combo_until"] = pygame.time.get_ticks() + 1400
        play("combo")


def register_wrong():
    if streak["count"] >= 3:
        streak["combo_msg"] = "Серия прервана"
        streak["combo_until"] = pygame.time.get_ticks() + 1000
    streak["count"] = 0


def draw_streak(now):
    if streak["count"] >= 2:
        x = W - 90
        y = 90
        draw_flame(x, y, 18)
        draw_text("x" + str(streak["count"]), 26, DARK, (x + 40, y + 5), bold=True)
    if now < streak["combo_until"] and streak["combo_msg"]:
        alpha_t = 1 - (streak["combo_until"] - now) / 1400
        r = pygame.Rect(0, 0, 400, 50)
        r.center = (W // 2, 180 - int(alpha_t * 30))
        col = GOLD if "Серия:" in streak["combo_msg"] else RED
        pygame.draw.rect(screen, col, r, border_radius=14)
        draw_text(streak["combo_msg"], 26, WHITE, r.center, bold=True)


# ================= СОСТОЯНИЯ =================
state = "menu"
selected_game = None
selected_level = 1

math_state = {}
dictation_state = {}
pattern_state = {}
symmetry_state = {}
words_state = {}
maze_state = {}

win_state = {"stars": 0, "game": None, "level": 1}
confetti = []
twinkle = [{"x": random.randint(20, W - 20), "y": random.randint(60, H - 60),
            "phase": random.random() * 6.28, "speed": random.uniform(0.8, 2.0)}
           for _ in range(40)]

BACK = pygame.Rect(24, 22, 130, 56)
SETTINGS_BTN = pygame.Rect(W - 300, 24, 130, 56)
ACHIEVE_BTN = pygame.Rect(W - 160, 24, 130, 56)

path_scroll = 0.0
path_target = 0.0


def draw_back():
    draw_button(BACK, (170, 170, 190), "◀ Назад", WHITE, 24)


def draw_header(text):
    draw_text(text, 38, DARK, (W // 2, 50), bold=True)


def draw_progress_dots(done, total):
    for i in range(total):
        x = W // 2 - (total - 1) * 15 + i * 30
        pygame.draw.circle(screen, GREEN if i < done else GRAY, (x, 108), 9)


# ================= МЕНЮ =================
def menu_layout():
    cards = []
    cw, ch = 440, 195
    pos = [(50, 150), (510, 150), (50, 360), (510, 360), (50, 570), (510, 570)]
    for g, (x, y) in zip(GAMES, pos):
        cards.append((pygame.Rect(x, y, cw, ch), g))
    return cards


MENU_CARDS = menu_layout()


def draw_game_icon(gid, rect):
    if gid == "math":
        draw_text("3 + 4 = ?", 42, BLUE, rect.center, bold=True)
    elif gid == "dictation":
        for i in range(3):
            for j in range(2):
                r = pygame.Rect(rect.centerx - 60 + i * 40, rect.centery - 25 + j * 40, 34, 34)
                pygame.draw.rect(screen, GREEN, r, 3, border_radius=5)
        draw_text("→", 42, DARK, (rect.centerx + 80, rect.centery), bold=True)
    elif gid == "pattern":
        for i, s in enumerate(["circle", "square", "circle", "square"]):
            draw_shape(screen, s, ORANGE if i % 2 == 0 else PURPLE,
                       pygame.Rect(rect.centerx - 90 + i * 50, rect.centery - 22, 44, 44))
    elif gid == "symmetry":
        pygame.draw.line(screen, DARK, (rect.centerx, rect.centery - 40), (rect.centerx, rect.centery + 40), 3)
        draw_shape(screen, "heart", PINK, pygame.Rect(rect.centerx - 80, rect.centery - 25, 50, 50))
        draw_shape(screen, "heart", PINK, pygame.Rect(rect.centerx + 30, rect.centery - 25, 50, 50))
    elif gid == "words":
        draw_text("К_Т", 44, PURPLE, (rect.centerx - 20, rect.centery), bold=True)
        draw_text("?", 44, ORANGE, (rect.centerx + 70, rect.centery), bold=True)
    elif gid == "maze":
        for i in range(4):
            pygame.draw.line(screen, TEAL, (rect.centerx - 70, rect.centery - 30 + i * 20),
                             (rect.centerx + 70, rect.centery - 30 + i * 20), 3)
        pygame.draw.line(screen, TEAL, (rect.centerx - 70, rect.centery - 30),
                         (rect.centerx - 70, rect.centery + 30), 3)
        pygame.draw.line(screen, TEAL, (rect.centerx + 70, rect.centery - 30),
                         (rect.centerx + 70, rect.centery + 30), 3)


def draw_twinkle(now):
    for s in twinkle:
        alpha = 0.5 + 0.5 * math.sin(now * 0.001 * s["speed"] + s["phase"])
        c = tuple(int(200 + 55 * alpha) for _ in range(3))
        r = int(2 + 2 * alpha)
        pygame.draw.circle(screen, c, (s["x"], s["y"]), r)


def draw_menu(now):
    screen.fill(BG)
    draw_twinkle(now)
    draw_text("Весёлая Игротека", 58, DARK, (W // 2, 55), bold=True)
    ts = total_stars()
    star_box = pygame.Rect(W // 2 - 130, 100, 260, 36)
    pygame.draw.rect(screen, WHITE, star_box, border_radius=18)
    pygame.draw.rect(screen, YELLOW, star_box, 3, border_radius=18)
    draw_star(star_box.x + 20, star_box.centery, 14, YELLOW, True)
    draw_text(str(ts), 24, DARK, (star_box.x + 100, star_box.centery), bold=True)

    draw_button(SETTINGS_BTN, (170, 170, 190), "Настройки", WHITE, 22)
    draw_button(ACHIEVE_BTN, (170, 170, 190), "Награды", WHITE, 22)

    for r, g in MENU_CARDS:
        pygame.draw.rect(screen, darker(g["color"]), r.move(0, 8), border_radius=22)
        pygame.draw.rect(screen, WHITE, r, border_radius=22)
        pygame.draw.rect(screen, g["color"], r, 6, border_radius=22)
        draw_text(g["title"], 34, DARK, (r.centerx, r.y + 40), bold=True)
        draw_text(g["sub"], 22, (150, 150, 170), (r.centerx, r.y + 76))
        draw_game_icon(g["id"], pygame.Rect(r.centerx - 100, r.y + 100, 200, 60))
        cur = current_level(g["id"])
        gs = game_stars(g["id"])
        draw_text("Ур. %d" % cur, 20, g["color"], (r.x + 55, r.bottom - 30), bold=True)
        draw_star(r.right - 80, r.bottom - 32, 12, YELLOW, True)
        draw_text(str(gs), 20, DARK, (r.right - 45, r.bottom - 32), bold=True)


# ================= УРОВНИ =================
PATH_TOP = 180


def world_y(lvl):
    return 380 + (lvl - 1) * 105


def node_pos(lvl):
    y = world_y(lvl) - path_scroll
    x = W // 2 + int(80 * math.sin(lvl * 1.2))
    return x, int(y)


def center_current(gid):
    cur = current_level(gid)
    return world_y(cur) - 430


def clamp_scroll(scroll, gid):
    cur = current_level(gid)
    min_s = world_y(1) - 250
    max_s = world_y(cur + 4) - H + 200
    if max_s < min_s:
        return min_s
    return max(min_s, min(max_s, scroll))


def difficulty_layout():
    bw, bh, gap = 160, 56, 20
    total = len(DIFFICULTIES) * bw + (len(DIFFICULTIES) - 1) * gap
    x0 = W // 2 - total // 2
    return [(pygame.Rect(x0 + i * (bw + gap), 100, bw, bh), d) for i, d in enumerate(DIFFICULTIES)]


def draw_levels(now):
    screen.fill(BG)
    g = selected_game
    gid = g["id"]

    cur = current_level(gid)
    max_shown = cur + 4

    for lvl in range(1, max_shown + 1):
        x1, y1 = node_pos(lvl)
        if y1 < PATH_TOP - 100 or y1 > H + 100:
            continue
        if lvl + 1 > max_shown:
            break
        x2, y2 = node_pos(lvl + 1)
        if y2 < PATH_TOP - 100 or y2 > H + 100:
            continue
        if y1 < PATH_TOP and y2 < PATH_TOP:
            continue
        completed = level_stars(gid, lvl) > 0
        color = g["color"] if completed else (200, 200, 210)
        p1, p2 = (x1, y1), (x2, y2)
        if p1[1] < PATH_TOP:
            t = (PATH_TOP - p1[1]) / (p2[1] - p1[1])
            p1 = (int(p1[0] + (p2[0] - p1[0]) * t), PATH_TOP)
        if p2[1] < PATH_TOP:
            t = (PATH_TOP - p2[1]) / (p1[1] - p2[1])
            p2 = (int(p2[0] + (p1[0] - p2[0]) * t), PATH_TOP)
        pygame.draw.line(screen, color, p1, p2, 12)

    for lvl in range(1, max_shown + 1):
        x, y = node_pos(lvl)
        if y < PATH_TOP - 60 or y > H + 60:
            continue
        stars = level_stars(gid, lvl)
        unlocked = level_unlocked(gid, lvl)
        is_current = (lvl == cur)
        r_node = 38
        if is_current:
            pulse = 1 + 0.08 * math.sin(now * 0.006)
            r_node = int(38 * pulse)

        if y < PATH_TOP:
            if y < PATH_TOP - 15:
                continue

        if not unlocked:
            pygame.draw.circle(screen, darker(GRAY, 20), (x, y), r_node)
            pygame.draw.circle(screen, (170, 170, 180), (x, y), r_node, 4)
            draw_lock(x, y - 4, 14)
        else:
            pygame.draw.circle(screen, darker(g["color"], 40), (x, y + 4), r_node)
            pygame.draw.circle(screen, g["color"], (x, y), r_node)
            pygame.draw.circle(screen, WHITE, (x, y), r_node, 4)
            if is_current:
                pygame.draw.circle(screen, GOLD, (x, y), r_node + 6, 4)
            draw_text(str(lvl), 30, WHITE, (x, y - 4), bold=True)
            for s in range(3):
                sx = x - 18 + s * 18
                draw_star(sx, y + 22, 7, YELLOW, s < stars)

    header_bg = pygame.Surface((W, PATH_TOP))
    header_bg.fill(BG)
    screen.blit(header_bg, (0, 0))

    draw_text(g["title"], 42, DARK, (W // 2, 50), bold=True)
    cur_diff = get_difficulty(gid)
    draw_text("Сложность:", 20, (150, 150, 170), (W // 2, 82), bold=True)
    for r, d in difficulty_layout():
        active = (d["id"] == cur_diff)
        col = d["color"] if active else (200, 200, 210)
        draw_button(r, col, d["name"], WHITE if active else DARK, 22)
        if active:
            pygame.draw.rect(screen, darker(col, 40), r, 4, border_radius=18)

    draw_back()
    draw_text("Уровень %d" % cur, 26, DARK, (W // 2, 750), bold=True)
    draw_text("★ %d" % game_stars(gid), 22, YELLOW, (W - 100, 750), bold=True)
    mascot.draw(W - 70, 700, 34, now)


# ================= ПОБЕДА =================
def spawn_confetti():
    global confetti
    confetti = [{"x": random.randint(0, W), "y": random.randint(-H, 0),
                 "vy": random.randint(2, 6),
                 "c": random.choice([RED, GREEN, BLUE, YELLOW, PURPLE, ORANGE, PINK]),
                 "r": random.randint(4, 10)} for _ in range(80)]


def update_confetti():
    for p in confetti:
        p["y"] += p["vy"]
        if p["y"] > H + 20:
            p["y"] = random.randint(-100, -10)
            p["x"] = random.randint(0, W)


def draw_confetti():
    for p in confetti:
        pygame.draw.circle(screen, p["c"], (int(p["x"]), int(p["y"])), p["r"])


def win_layout():
    bw, bh = 240, 80
    btns = []
    btns.append((pygame.Rect(W // 2 - bw - 20, 460, bw, bh), "retry"))
    btns.append((pygame.Rect(W // 2 + 20, 460, bw, bh), "next"))
    btns.append((pygame.Rect(W // 2 - bw // 2, 580, bw, bh), "levels"))
    return btns


def finish_level(game_id, mistakes):
    global state
    diff = get_difficulty(game_id)
    if mistakes == 0:
        stars = 3
    elif mistakes <= 2:
        stars = 2
    else:
        stars = 1

    key = str(selected_level)
    cur_best = level_stars(game_id, selected_level)
    if stars > cur_best:
        progress.setdefault(game_id, {}).setdefault("stars", {})[key] = stars
        save_progress(progress)

    if diff == "hard":
        progress.setdefault("stats", {})["hard_wins"] = progress.get("stats", {}).get("hard_wins", 0) + 1

    win_state["stars"] = stars
    win_state["game"] = game_id
    win_state["level"] = selected_level
    state = "win"
    spawn_confetti()
    play("win")
    mascot.set_mood("happy", 3000)
    check_achievements()


def draw_win(now):
    screen.fill(BG)
    draw_confetti()
    draw_text("Молодец!", 78, DARK, (W // 2, 130), bold=True)
    for i in range(3):
        cx = W // 2 - 130 + i * 130
        draw_star(cx, 270, 55, YELLOW, i < win_state["stars"])
    if win_state["stars"] == 3:
        draw_text("Идеально! Без ошибок!", 28, GREEN, (W // 2, 365), bold=True)
    elif win_state["stars"] == 2:
        draw_text("Очень хорошо!", 26, BLUE, (W // 2, 365), bold=True)
    else:
        draw_text("Получилось!", 26, TEAL, (W // 2, 365), bold=True)

    names = {"retry": "Ещё раз", "next": "Дальше", "levels": "Уровни"}
    colors = {"retry": BLUE, "next": GREEN, "levels": (170, 170, 190)}
    for r, action in win_layout():
        draw_button(r, colors[action], names[action], WHITE, 28)

    mascot.draw(W - 80, 720, 45, now)


# ================= НАСТРОЙКИ =================
def draw_settings(now):
    screen.fill(BG)
    draw_text("Настройки", 54, DARK, (W // 2, 80), bold=True)

    sound_on = progress.get("settings", {}).get("sound", True)
    draw_text("Звук", 36, DARK, (W // 2 - 100, 245), bold=True)
    toggle_rect = pygame.Rect(W // 2 + 40, 215, 160, 60)
    draw_button(toggle_rect, GREEN if sound_on else GRAY, "Вкл" if sound_on else "Выкл", WHITE, 28)

    reset_rect = pygame.Rect(W // 2 - 220, 360, 440, 80)
    draw_button(reset_rect, RED, "Сбросить прогресс", WHITE, 28)
    draw_text("(все звёзды и достижения пропадут)", 18, (170, 170, 190), (W // 2, 470))

    draw_text("Всего звёзд: %d" % total_stars(), 24, DARK, (W // 2, 540), bold=True)
    draw_text("Рекорд серии: %d" % streak["best"], 22, FIRE, (W // 2, 580), bold=True)
    draw_back()


def settings_click(pos):
    sound_on = progress.get("settings", {}).get("sound", True)
    if pygame.Rect(W // 2 + 40, 215, 160, 60).collidepoint(pos):
        progress.setdefault("settings", {})["sound"] = not sound_on
        save_progress(progress)
        play("click")
        return
    if pygame.Rect(W // 2 - 220, 360, 440, 80).collidepoint(pos):
        for g in GAMES:
            progress[g["id"]] = {"stars": {}, "difficulty": "normal"}
        progress["achievements"] = {}
        progress["stats"] = {}
        streak["best"] = 0
        streak["count"] = 0
        save_progress(progress)
        play("back")
        show_toast("Прогресс сброшен", RED)


# ================= ДОСТИЖЕНИЯ ЭКРАН =================
def draw_achievements(now):
    screen.fill(BG)
    draw_text("Награды", 54, DARK, (W // 2, 60), bold=True)
    unlocked_count = sum(1 for a in ACHIEVEMENTS if progress.get("achievements", {}).get(a["id"]))
    draw_text("%d из %d" % (unlocked_count, len(ACHIEVEMENTS)), 22, (150, 150, 170), (W // 2, 105), bold=True)

    cw, ch = 440, 92
    gap = 18
    cols = 2
    total_w = cols * cw + gap
    x0 = W // 2 - total_w // 2
    y0 = 150
    for i, a in enumerate(ACHIEVEMENTS):
        col = i % cols
        row = i // cols
        r = pygame.Rect(x0 + col * (cw + gap), y0 + row * (ch + 10), cw, ch)
        if r.bottom > H - 40:
            break
        unlocked = progress.get("achievements", {}).get(a["id"], False)
        bg_col = (245, 250, 235) if unlocked else (235, 235, 245)
        border = GREEN if unlocked else GRAY
        pygame.draw.rect(screen, bg_col, r, border_radius=16)
        pygame.draw.rect(screen, border, r, 4, border_radius=16)
        if unlocked:
            draw_medal(r.x + 50, r.centery, 26)
        else:
            draw_lock(r.x + 50, r.centery, 18)
        draw_text(a["title"], 24, DARK if unlocked else (150, 150, 170), (r.x + 100, r.y + 32), bold=True)
        draw_text(a["desc"], 17, (140, 140, 170), (r.x + 100, r.y + 64))
    draw_back()


# ================= ГЕНЕРАТОРЫ =================
def gen_positions(n, area):
    if n <= 0:
        return []
    cols = min(n, max(1, int(area.w / 95)))
    rows = max(1, math.ceil(n / cols))
    cw = area.w / cols
    ch = area.h / rows
    pts, idx = [], 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            cx = area.left + c * cw + cw / 2
            cy = area.top + r * ch + ch / 2
            pts.append((cx + random.uniform(-cw * 0.18, cw * 0.18),
                        cy + random.uniform(-ch * 0.18, ch * 0.18)))
            idx += 1
    random.shuffle(pts)
    return pts


# ================= ИГРА: СЧЁТ =================
def math_gen(level, diff):
    if diff == "easy":
        if level <= 3:
            max_val = 5
            concepts = ["add"]
        elif level <= 6:
            max_val = 8
            concepts = ["add", "add_missing"]
        else:
            max_val = 10
            concepts = ["add", "add_missing", "sub"]
        spread = 3
    elif diff == "normal":
        if level <= 2:
            max_val = 10
            concepts = ["add"]
        elif level <= 4:
            max_val = 10
            concepts = ["add", "add_missing"]
        elif level <= 6:
            max_val = 10
            concepts = ["add", "add_missing", "sub"]
        else:
            max_val = 10
            concepts = ["add", "add_missing", "sub", "sub_missing"]
        spread = 2
    else:
        max_val = 10
        if level <= 2:
            concepts = ["add", "sub", "add_missing", "sub_missing"]
        else:
            concepts = ["add", "sub", "add_missing", "sub_missing", "add_missing2"]
        spread = 1

    c = random.choice(concepts)
    if c == "add":
        a = random.randint(0, max_val)
        b = random.randint(0, max_val - a)
        tokens, ans = [str(a), "+", str(b), "=", "?"], a + b
    elif c == "add_missing":
        cc = random.randint(1, max_val)
        a = random.randint(0, cc)
        tokens, ans = [str(a), "+", "?", "=", str(cc)], cc - a
    elif c == "add_missing2":
        cc = random.randint(1, max_val)
        b = random.randint(0, cc)
        tokens, ans = ["?", "+", str(b), "=", str(cc)], cc - b
    elif c == "sub":
        a = random.randint(1, max_val)
        b = random.randint(0, a)
        tokens, ans = [str(a), "-", str(b), "=", "?"], a - b
    else:
        a = random.randint(1, max_val)
        r = random.randint(0, a)
        tokens, ans = [str(a), "-", "?", "=", str(r)], a - r

    opts = {ans}
    guard = 0
    while len(opts) < 4 and guard < 200:
        guard += 1
        off = random.choice([-spread, -spread + 1, spread - 1, spread])
        if off == 0:
            continue
        v = ans + off
        if 0 <= v <= max_val:
            opts.add(v)
    while len(opts) < 4:
        v = random.randint(0, max_val)
        if v != ans:
            opts.add(v)
    opts = list(opts)
    random.shuffle(opts)
    return tokens, ans, opts


def math_opt_rects(n, y=520):
    bw, bh, gap = 130, 110, 28
    total = n * bw + (n - 1) * gap
    x0 = W // 2 - total // 2
    return [pygame.Rect(x0 + i * (bw + gap), y, bw, bh) for i in range(n)]


def start_math(level):
    math_state.clear()
    math_state.update({
        "level": level, "diff": get_difficulty("math"),
        "round": 0, "total": 5, "mistakes": 0,
        "tokens": [], "answer": 0, "option_rects": [],
        "wrong": None, "flash": None, "flash_until": 0, "waiting_next": False,
    })
    new_math_problem()


def new_math_problem():
    tokens, ans, opts = math_gen(math_state["level"], math_state["diff"])
    math_state["tokens"] = tokens
    math_state["answer"] = ans
    math_state["option_rects"] = list(zip(math_opt_rects(len(opts)), opts))
    math_state["wrong"] = None
    math_state["flash"] = None
    math_state["waiting_next"] = False


def math_click(pos):
    if math_state["waiting_next"]:
        return
    for r, v in math_state["option_rects"]:
        if r.collidepoint(pos):
            now = pygame.time.get_ticks()
            if v == math_state["answer"]:
                math_state["flash"] = "ok"
                math_state["waiting_next"] = True
                math_state["flash_until"] = now + 800
                play("correct")
                burst(r.centerx, r.centery, GREEN, 25)
                mascot.set_mood("happy", 700)
                register_correct()
            else:
                math_state["flash"] = "bad"
                math_state["wrong"] = v
                math_state["flash_until"] = now + 500
                math_state["mistakes"] += 1
                play("wrong")
                burst(r.centerx, r.centery, RED, 12, 3)
                mascot.set_mood("sad", 700)
                screen_shake(10)
                register_wrong()
            break


def draw_math_tokens(tokens, cy):
    f = font(74, True)
    items = []
    for t in tokens:
        if t in "+-=":
            items.append((t, f.size(t)[0] + 28))
        else:
            items.append((t, 90))
    gap = 14
    total = sum(w for _, w in items) + gap * (len(items) - 1)
    x = W // 2 - total // 2
    for t, w in items:
        r = pygame.Rect(x, cy - 50, w, 100)
        if t in "+-=":
            draw_text(t, 74, DARK, r.center, bold=True)
        elif t == "?":
            pygame.draw.rect(screen, WHITE, r, border_radius=16)
            pygame.draw.rect(screen, ORANGE, r, 5, border_radius=16)
            draw_text("?", 74, ORANGE, r.center, bold=True)
        else:
            pygame.draw.rect(screen, WHITE, r, border_radius=16)
            pygame.draw.rect(screen, BLUE, r, 5, border_radius=16)
            draw_text(t, 74, DARK, r.center, bold=True)
        x += w + gap


def draw_math(now):
    screen.fill(BG)
    draw_header("Счёт до 10 — Ур. %d" % math_state["level"])
    draw_progress_dots(math_state["round"], math_state["total"])
    draw_text("Какое число спряталось?", 26, (140, 140, 160), (W // 2, 155), bold=True)
    draw_math_tokens(math_state["tokens"], 280)
    for r, v in math_state["option_rects"]:
        col = YELLOW
        if math_state["waiting_next"] and v == math_state["answer"]:
            col = GREEN
        elif math_state["flash"] == "bad" and math_state["wrong"] == v and now < math_state["flash_until"]:
            col = RED
        draw_button(r, col, str(v), WHITE, 62)
    if math_state["flash"] and now < math_state["flash_until"]:
        if math_state["flash"] == "ok":
            draw_check(W // 2, 465, 34)
        else:
            draw_cross(W // 2, 465, 30)
    mascot.draw(W - 70, 700, 34, now)


# ================= ИГРА: ГРАФИЧЕСКИЙ ДИКТАНТ =================
DICT_DIRS = [
    ("up", (0, -1), "↑"),
    ("down", (0, 1), "↓"),
    ("left", (-1, 0), "←"),
    ("right", (1, 0), "→"),
]


def start_dictation(level):
    dictation_state.clear()
    grid_n = 6
    start = (2, 2)
    x, y = start
    steps_len = min(3 + level, 10)
    seq = []
    for _ in range(steps_len):
        valid = []
        for name, (dx, dy), sym in DICT_DIRS:
            nx, ny = x + dx, y + dy
            if 0 <= nx < grid_n and 0 <= ny < grid_n:
                valid.append((name, dx, dy, sym, nx, ny))
        name, dx, dy, sym, nx, ny = random.choice(valid)
        seq.append({"name": name, "dx": dx, "dy": dy, "sym": sym})
        x, y = nx, ny
    dictation_state.update({
        "level": level, "diff": get_difficulty("dictation"),
        "grid_n": grid_n, "start": start, "pos": start,
        "steps": seq, "idx": 0, "mistakes": 0,
        "path": [start], "flash": None, "flash_until": 0,
    })


def dict_buttons():
    bw, bh, gap = 100, 70, 20
    cx = W // 2
    y = 560
    return [
        (pygame.Rect(cx - bw // 2, y, bw, bh), "up"),
        (pygame.Rect(cx - bw - gap, y + bh + gap, bw, bh), "left"),
        (pygame.Rect(cx - bw // 2, y + bh + gap, bw, bh), "down"),
        (pygame.Rect(cx + bw // 2 + gap, y + bh + gap, bw, bh), "right"),
    ]


def dictation_click(pos):
    if dictation_state["idx"] >= len(dictation_state["steps"]):
        return
    now = pygame.time.get_ticks()
    for r, name in dict_buttons():
        if r.collidepoint(pos):
            expected = dictation_state["steps"][dictation_state["idx"]]
            if name == expected["name"]:
                x, y = dictation_state["pos"]
                x += expected["dx"]
                y += expected["dy"]
                dictation_state["pos"] = (x, y)
                dictation_state["path"].append((x, y))
                dictation_state["idx"] += 1
                play("correct")
                burst(r.centerx, r.centery, GREEN, 18)
                mascot.set_mood("happy", 500)
                register_correct()
                if dictation_state["idx"] >= len(dictation_state["steps"]):
                    finish_level("dictation", dictation_state["mistakes"])
            else:
                dictation_state["mistakes"] += 1
                dictation_state["flash"] = name
                dictation_state["flash_until"] = now + 400
                play("wrong")
                screen_shake(8)
                mascot.set_mood("sad", 500)
                register_wrong()
            break


def draw_dictation(now):
    screen.fill(BG)
    draw_header("Графический диктант — Ур. %d" % dictation_state["level"])
    steps = dictation_state["steps"]
    idx = dictation_state["idx"]
    draw_text("Повтори путь по стрелкам", 24, (140, 140, 160), (W // 2, 150), bold=True)
    draw_text(" ".join(s["sym"] for s in steps), 34, DARK, (W // 2, 185), bold=True)

    n = dictation_state["grid_n"]
    cell = 60
    x0 = W // 2 - n * cell // 2
    y0 = 220
    path = set(dictation_state["path"])
    for gy in range(n):
        for gx in range(n):
            r = pygame.Rect(x0 + gx * cell, y0 + gy * cell, cell, cell)
            pygame.draw.rect(screen, WHITE, r)
            pygame.draw.rect(screen, GRAY, r, 2)
            if (gx, gy) in path:
                pygame.draw.rect(screen, (220, 245, 225), r.inflate(-6, -6), border_radius=8)
    px, py = dictation_state["pos"]
    cx = x0 + px * cell + cell // 2
    cy = y0 + py * cell + cell // 2
    pygame.draw.circle(screen, TEAL, (cx, cy), 18)
    pygame.draw.circle(screen, WHITE, (cx, cy), 18, 3)

    for r, name in dict_buttons():
        col = YELLOW
        if dictation_state["flash"] == name and now < dictation_state["flash_until"]:
            col = RED
        draw_button(r, col, {"up": "↑", "down": "↓", "left": "←", "right": "→"}[name], WHITE, 42)

    draw_text("Шаг %d из %d" % (min(idx + 1, len(steps)), len(steps)), 22, DARK, (W // 2, 520), bold=True)
    mascot.draw(W - 70, 700, 34, now)


# ================= ИГРА: ПРОДОЛЖИ УЗОР =================
def pattern_gen(level, diff):
    if diff == "easy":
        period = 2
        n_show = 5
    elif diff == "normal":
        period = random.choice([2, 3])
        n_show = 6
    else:
        period = random.choice([2, 3, 4])
        n_show = 7
    combos = random.sample([(s, c) for s in SHAPES for c in SHAPE_COLORS], period)
    full = [combos[i % period] for i in range(n_show)]
    answer = full[-1]
    display = full[:-1] + ["?"]
    options = {answer}
    guard = 0
    while len(options) < 4 and guard < 300:
        guard += 1
        options.add(random.choice([(s, c) for s in SHAPES for c in SHAPE_COLORS]))
    options = list(options)
    random.shuffle(options)
    return display, answer, options


def start_pattern(level):
    pattern_state.clear()
    pattern_state.update({
        "level": level, "diff": get_difficulty("pattern"),
        "round": 0, "total": 5, "mistakes": 0,
        "display": [], "answer": None, "option_rects": [],
        "wrong": None, "flash": None, "flash_until": 0, "waiting_next": False,
    })
    new_pattern_round()


def new_pattern_round():
    display, ans, opts = pattern_gen(pattern_state["level"], pattern_state["diff"])
    pattern_state["display"] = display
    pattern_state["answer"] = ans
    pattern_state["option_rects"] = list(zip(math_opt_rects(len(opts)), opts))
    pattern_state["wrong"] = None
    pattern_state["flash"] = None
    pattern_state["waiting_next"] = False


def pattern_click(pos):
    if pattern_state["waiting_next"]:
        return
    for r, v in pattern_state["option_rects"]:
        if r.collidepoint(pos):
            now = pygame.time.get_ticks()
            if v == pattern_state["answer"]:
                pattern_state["flash"] = "ok"
                pattern_state["waiting_next"] = True
                pattern_state["flash_until"] = now + 700
                play("correct")
                burst(r.centerx, r.centery, GREEN, 25)
                mascot.set_mood("happy", 700)
                register_correct()
            else:
                pattern_state["flash"] = "bad"
                pattern_state["wrong"] = v
                pattern_state["flash_until"] = now + 500
                pattern_state["mistakes"] += 1
                play("wrong")
                burst(r.centerx, r.centery, RED, 12, 3)
                mascot.set_mood("sad", 700)
                screen_shake(10)
                register_wrong()
            break


def draw_pattern(now):
    screen.fill(BG)
    draw_header("Продолжи узор — Ур. %d" % pattern_state["level"])
    draw_progress_dots(pattern_state["round"], pattern_state["total"])
    draw_text("Что должно быть дальше?", 26, (140, 140, 160), (W // 2, 155), bold=True)

    display = pattern_state["display"]
    n = len(display)
    bw, gap = 82, 12
    total = n * bw + (n - 1) * gap
    x0 = W // 2 - total // 2
    cy = 290
    for i, item in enumerate(display):
        r = pygame.Rect(x0 + i * (bw + gap), cy - 45, bw, 90)
        pygame.draw.rect(screen, WHITE, r, border_radius=14)
        pygame.draw.rect(screen, ORANGE if item == "?" else TEAL, r, 4, border_radius=14)
        if item == "?":
            draw_text("?", 50, ORANGE, r.center, bold=True)
        else:
            draw_shape(screen, item[0], item[1], r.inflate(-26, -26))

    for r, v in pattern_state["option_rects"]:
        border = YELLOW
        if pattern_state["waiting_next"] and v == pattern_state["answer"]:
            border = GREEN
        elif pattern_state["flash"] == "bad" and pattern_state["wrong"] == v and now < pattern_state["flash_until"]:
            border = RED
        pygame.draw.rect(screen, darker(border, 40), r.move(0, 6), border_radius=18)
        pygame.draw.rect(screen, WHITE, r, border_radius=18)
        pygame.draw.rect(screen, border, r, 6, border_radius=18)
        draw_shape(screen, v[0], v[1], r.inflate(-44, -44))

    if pattern_state["flash"] and now < pattern_state["flash_until"]:
        if pattern_state["flash"] == "ok":
            draw_check(W // 2, 470, 30)
        else:
            draw_cross(W // 2, 470, 28)
    mascot.draw(W - 70, 700, 34, now)


# ================= ИГРА: СИММЕТРИЯ =================
def start_symmetry(level):
    symmetry_state.clear()
    n = 6
    count = min(3 + level, 9)
    filled = set()
    while len(filled) < count:
        x = random.randint(0, n // 2 - 1)
        y = random.randint(0, n - 1)
        filled.add((x, y))
    required = set((n - 1 - x, y) for x, y in filled)
    symmetry_state.update({
        "level": level, "n": n,
        "filled": filled, "required": required, "mirrored": set(),
        "mistakes": 0, "flash": None, "flash_until": 0,
    })


def symmetry_click(pos):
    n = symmetry_state["n"]
    cell = 64
    x0 = W // 2 - n * cell // 2
    y0 = 220
    gx = (pos[0] - x0) // cell
    gy = (pos[1] - y0) // cell
    if not (0 <= gx < n and 0 <= gy < n):
        return
    if gx < n // 2:
        return
    now = pygame.time.get_ticks()
    if (gx, gy) in symmetry_state["mirrored"]:
        return
    if (gx, gy) in symmetry_state["required"]:
        symmetry_state["mirrored"].add((gx, gy))
        play("correct")
        burst(x0 + gx * cell + cell // 2, y0 + gy * cell + cell // 2, GREEN, 16)
        mascot.set_mood("happy", 500)
        register_correct()
        if symmetry_state["required"] <= symmetry_state["mirrored"]:
            finish_level("symmetry", symmetry_state["mistakes"])
    else:
        symmetry_state["mistakes"] += 1
        symmetry_state["flash"] = (gx, gy)
        symmetry_state["flash_until"] = now + 400
        play("wrong")
        screen_shake(8)
        mascot.set_mood("sad", 500)
        register_wrong()


def draw_symmetry(now):
    screen.fill(BG)
    draw_header("Симметрия — Ур. %d" % symmetry_state["level"])
    draw_text("Дорисуй правую половину", 26, (140, 140, 160), (W // 2, 155), bold=True)

    n = symmetry_state["n"]
    cell = 64
    x0 = W // 2 - n * cell // 2
    y0 = 220
    for gy in range(n):
        for gx in range(n):
            r = pygame.Rect(x0 + gx * cell, y0 + gy * cell, cell, cell)
            pygame.draw.rect(screen, WHITE, r)
            pygame.draw.rect(screen, GRAY, r, 2)
            if (gx, gy) in symmetry_state["filled"] or (gx, gy) in symmetry_state["mirrored"]:
                draw_shape(screen, "square", PINK, r.inflate(-18, -18))
            if symmetry_state["flash"] == (gx, gy) and now < symmetry_state["flash_until"]:
                pygame.draw.rect(screen, RED, r.inflate(-4, -4), 5, border_radius=8)
    pygame.draw.line(screen, DARK, (x0 + n // 2 * cell, y0),
                     (x0 + n // 2 * cell, y0 + n * cell), 5)
    mascot.draw(W - 70, 700, 34, now)


# ================= ИГРА: СЛОВЕСНЫЕ ИГРЫ =================
WORDS_RU = [
    "МАМА", "ПАПА", "СОБАКА", "КОШКА", "МОЛОКО", "ШКОЛА", "КНИГА", "СТОЛ",
    "ОКНО", "ДОМ", "СОЛНЦЕ", "ЛУНА", "ЗВЕЗДА", "РЫБА", "ПТИЦА", "ЦВЕТОК",
    "ДЕРЕВО", "ЯБЛОКО", "МЯЧ", "КУКЛА", "ДРУГ", "ИГРА", "ЛЕС", "РЕКА",
]
ALPHABET_RU = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"


def start_words(level):
    words_state.clear()
    words_state.update({
        "level": level, "diff": get_difficulty("words"),
        "round": 0, "total": 5, "mistakes": 0,
        "word": "", "display": "", "answer": "", "option_rects": [],
        "wrong": None, "flash": None, "flash_until": 0, "waiting_next": False,
    })
    new_words_round()


def new_words_round():
    level = words_state["level"]
    diff = words_state["diff"]
    if diff == "easy":
        pool = [w for w in WORDS_RU if 3 <= len(w) <= 5]
    elif diff == "normal":
        pool = [w for w in WORDS_RU if 4 <= len(w) <= 7]
    else:
        pool = [w for w in WORDS_RU if len(w) >= 5]
    word = random.choice(pool if pool else WORDS_RU)
    idx = random.randint(1, len(word) - 1)
    answer = word[idx]
    display = word[:idx] + "_" + word[idx + 1:]
    opts = {answer}
    guard = 0
    while len(opts) < 4 and guard < 300:
        guard += 1
        c = random.choice(ALPHABET_RU)
        if c != answer:
            opts.add(c)
    opts = list(opts)
    random.shuffle(opts)
    words_state["word"] = word
    words_state["display"] = display
    words_state["answer"] = answer
    words_state["option_rects"] = list(zip(math_opt_rects(len(opts)), opts))
    words_state["wrong"] = None
    words_state["flash"] = None
    words_state["waiting_next"] = False


def words_click(pos):
    if words_state["waiting_next"]:
        return
    for r, v in words_state["option_rects"]:
        if r.collidepoint(pos):
            now = pygame.time.get_ticks()
            if v == words_state["answer"]:
                words_state["flash"] = "ok"
                words_state["waiting_next"] = True
                words_state["flash_until"] = now + 700
                play("correct")
                burst(r.centerx, r.centery, GREEN, 25)
                mascot.set_mood("happy", 700)
                register_correct()
            else:
                words_state["flash"] = "bad"
                words_state["wrong"] = v
                words_state["flash_until"] = now + 500
                words_state["mistakes"] += 1
                play("wrong")
                burst(r.centerx, r.centery, RED, 12, 3)
                mascot.set_mood("sad", 700)
                screen_shake(10)
                register_wrong()
            break


def draw_words(now):
    screen.fill(BG)
    draw_header("Словесные игры — Ур. %d" % words_state["level"])
    draw_progress_dots(words_state["round"], words_state["total"])
    draw_text("Какая буква пропала?", 26, (140, 140, 160), (W // 2, 155), bold=True)

    word = words_state["display"]
    draw_text(word, 78, DARK, (W // 2, 280), bold=True)

    for r, v in words_state["option_rects"]:
        col = YELLOW
        if words_state["waiting_next"] and v == words_state["answer"]:
            col = GREEN
        elif words_state["flash"] == "bad" and words_state["wrong"] == v and now < words_state["flash_until"]:
            col = RED
        draw_button(r, col, v, WHITE, 54)

    if words_state["flash"] and now < words_state["flash_until"]:
        if words_state["flash"] == "ok":
            draw_check(W // 2, 470, 30)
        else:
            draw_cross(W // 2, 470, 28)
    mascot.draw(W - 70, 700, 34, now)


# ================= ИГРА: ЛАБИРИНТ =================
def generate_maze(size):
    grid = [[1] * size for _ in range(size)]
    stack = [(1, 1)]
    grid[1][1] = 0
    visited = {(1, 1)}
    while stack:
        x, y = stack[-1]
        neighbors = []
        for dx, dy in [(2, 0), (-2, 0), (0, 2), (0, -2)]:
            nx, ny = x + dx, y + dy
            if 1 <= nx < size - 1 and 1 <= ny < size - 1 and (nx, ny) not in visited:
                neighbors.append((nx, ny, dx // 2, dy // 2))
        if neighbors:
            nx, ny, mx, my = random.choice(neighbors)
            grid[y + my][x + mx] = 0
            grid[ny][nx] = 0
            visited.add((nx, ny))
            stack.append((nx, ny))
        else:
            stack.pop()
    return grid


def start_maze(level):
    size = min(5 + 2 * ((level - 1) // 2), 11)
    if size % 2 == 0:
        size += 1
    grid = generate_maze(size)
    maze_state.clear()
    maze_state.update({
        "level": level, "size": size, "grid": grid,
        "pos": (1, 1), "exit": (size - 2, size - 2),
        "mistakes": 0, "flash": None, "flash_until": 0,
    })


def maze_click(pos):
    size = maze_state["size"]
    cell = min(70, 600 // size)
    x0 = W // 2 - size * cell // 2
    y0 = 190
    gx = (pos[0] - x0) // cell
    gy = (pos[1] - y0) // cell
    if not (0 <= gx < size and 0 <= gy < size):
        return
    px, py = maze_state["pos"]
    if (gx, gy) == (px, py):
        return
    now = pygame.time.get_ticks()
    if abs(gx - px) + abs(gy - py) != 1 or maze_state["grid"][gy][gx] == 1:
        maze_state["mistakes"] += 1
        maze_state["flash"] = (gx, gy)
        maze_state["flash_until"] = now + 350
        play("wrong")
        screen_shake(7)
        mascot.set_mood("sad", 400)
        register_wrong()
        return
    maze_state["pos"] = (gx, gy)
    play("click")
    burst(x0 + gx * cell + cell // 2, y0 + gy * cell + cell // 2, TEAL, 10, 3)
    if (gx, gy) == maze_state["exit"]:
        finish_level("maze", maze_state["mistakes"])


def draw_maze(now):
    screen.fill(BG)
    draw_header("Лабиринт — Ур. %d" % maze_state["level"])
    draw_text("Дойди до звёздочки", 26, (140, 140, 160), (W // 2, 155), bold=True)

    size = maze_state["size"]
    cell = min(70, 600 // size)
    x0 = W // 2 - size * cell // 2
    y0 = 190
    for gy in range(size):
        for gx in range(size):
            r = pygame.Rect(x0 + gx * cell, y0 + gy * cell, cell, cell)
            if maze_state["grid"][gy][gx] == 1:
                pygame.draw.rect(screen, DARK, r)
            else:
                pygame.draw.rect(screen, WHITE, r)
                pygame.draw.rect(screen, GRAY, r, 1)

    ex, ey = maze_state["exit"]
    draw_star(x0 + ex * cell + cell // 2, y0 + ey * cell + cell // 2, cell // 3, GOLD, True)

    px, py = maze_state["pos"]
    pygame.draw.circle(screen, TEAL, (x0 + px * cell + cell // 2, y0 + py * cell + cell // 2), cell // 3)
    pygame.draw.circle(screen, WHITE, (x0 + px * cell + cell // 2, y0 + py * cell + cell // 2), cell // 3, 3)

    if maze_state["flash"] and now < maze_state["flash_until"]:
        gx, gy = maze_state["flash"]
        r = pygame.Rect(x0 + gx * cell, y0 + gy * cell, cell, cell)
        pygame.draw.rect(screen, RED, r.inflate(-4, -4), 4, border_radius=6)
    mascot.draw(W - 70, 700, 34, now)


# ================= ЛОГИКА =================
def start_game(gid, level):
    global state, selected_level
    state = "play"
    selected_level = level
    streak["count"] = 0
    if gid == "math":
        start_math(level)
    elif gid == "dictation":
        start_dictation(level)
    elif gid == "pattern":
        start_pattern(level)
    elif gid == "symmetry":
        start_symmetry(level)
    elif gid == "words":
        start_words(level)
    elif gid == "maze":
        start_maze(level)


def handle_click(pos):
    global state, selected_game, selected_level, path_scroll, path_target
    now = pygame.time.get_ticks()

    if state == "menu":
        for r, g in MENU_CARDS:
            if r.collidepoint(pos):
                play("click")
                selected_game = g
                state = "levels"
                path_scroll = clamp_scroll(center_current(g["id"]), g["id"])
                path_target = path_scroll
                return
        if SETTINGS_BTN.collidepoint(pos):
            play("click")
            state = "settings"
            return
        if ACHIEVE_BTN.collidepoint(pos):
            play("click")
            state = "achievements"
            return

    elif state == "levels":
        if BACK.collidepoint(pos):
            play("back")
            state = "menu"
            return
        for r, d in difficulty_layout():
            if r.collidepoint(pos):
                play("click")
                set_difficulty(selected_game["id"], d["id"])
                path_scroll = clamp_scroll(center_current(selected_game["id"]), selected_game["id"])
                path_target = path_scroll
                return
        gid = selected_game["id"]
        cur = current_level(gid)
        max_shown = cur + 4
        for lvl in range(1, max_shown + 1):
            if not level_unlocked(gid, lvl):
                continue
            x, y = node_pos(lvl)
            if y < PATH_TOP or y > H:
                continue
            d = math.hypot(pos[0] - x, pos[1] - y)
            if d <= 48:
                play("click")
                selected_level = lvl
                start_game(gid, lvl)
                return

    elif state == "play":
        if BACK.collidepoint(pos):
            play("back")
            state = "levels"
            path_scroll = clamp_scroll(center_current(selected_game["id"]), selected_game["id"])
            path_target = path_scroll
            return
        gid = selected_game["id"]
        if gid == "math":
            math_click(pos)
        elif gid == "dictation":
            dictation_click(pos)
        elif gid == "pattern":
            pattern_click(pos)
        elif gid == "symmetry":
            symmetry_click(pos)
        elif gid == "words":
            words_click(pos)
        elif gid == "maze":
            maze_click(pos)

    elif state == "win":
        for r, action in win_layout():
            if r.collidepoint(pos):
                play("click")
                if action == "retry":
                    start_game(win_state["game"], win_state["level"])
                elif action == "next":
                    start_game(win_state["game"], win_state["level"] + 1)
                elif action == "levels":
                    state = "levels"
                    path_scroll = clamp_scroll(center_current(win_state["game"]), win_state["game"])
                    path_target = path_scroll
                return

    elif state == "settings":
        if BACK.collidepoint(pos):
            play("back")
            state = "menu"
            return
        settings_click(pos)

    elif state == "achievements":
        if BACK.collidepoint(pos):
            play("back")
            state = "menu"
            return


def update(now):
    global path_scroll
    mascot.update(now)
    update_particles()

    if state == "levels":
        path_scroll += (path_target - path_scroll) * 0.15
        if abs(path_target - path_scroll) < 0.5:
            path_scroll = path_target

    if state == "win":
        update_confetti()
        return
    if state != "play":
        return

    gid = selected_game["id"]
    if gid == "math":
        if math_state["waiting_next"] and now >= math_state["flash_until"]:
            math_state["waiting_next"] = False
            math_state["round"] += 1
            if math_state["round"] >= math_state["total"]:
                finish_level("math", math_state["mistakes"])
            else:
                new_math_problem()
    elif gid == "pattern":
        if pattern_state["waiting_next"] and now >= pattern_state["flash_until"]:
            pattern_state["waiting_next"] = False
            pattern_state["round"] += 1
            if pattern_state["round"] >= pattern_state["total"]:
                finish_level("pattern", pattern_state["mistakes"])
            else:
                new_pattern_round()
    elif gid == "words":
        if words_state["waiting_next"] and now >= words_state["flash_until"]:
            words_state["waiting_next"] = False
            words_state["round"] += 1
            if words_state["round"] >= words_state["total"]:
                finish_level("words", words_state["mistakes"])
            else:
                new_words_round()


def draw(now):
    if state == "menu":
        draw_menu(now)
    elif state == "levels":
        draw_levels(now)
    elif state == "play":
        gid = selected_game["id"]
        if gid == "math":
            draw_math(now)
        elif gid == "dictation":
            draw_dictation(now)
        elif gid == "pattern":
            draw_pattern(now)
        elif gid == "symmetry":
            draw_symmetry(now)
        elif gid == "words":
            draw_words(now)
        elif gid == "maze":
            draw_maze(now)
        draw_back()
        draw_streak(now)
    elif state == "win":
        draw_win(now)
    elif state == "settings":
        draw_settings(now)
    elif state == "achievements":
        draw_achievements(now)

    if state == "play" or state == "win":
        draw_particles()
    draw_toast(now)


# ================= ГЛАВНЫЙ ЦИКЛ (WEB) =================
async def main():
    global running, state, path_scroll, path_target
    running = True

    while running:
        clock.tick(60)
        now = pygame.time.get_ticks()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                if state in ("levels", "settings", "achievements"):
                    state = "menu"
                elif state == "play":
                    state = "levels"
                    path_scroll = clamp_scroll(center_current(selected_game["id"]), selected_game["id"])
                    path_target = path_scroll
                elif state == "win":
                    state = "levels"
                    path_scroll = clamp_scroll(center_current(win_state["game"]), win_state["game"])
                    path_target = path_scroll
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    handle_click(event.pos)
                elif state == "levels":
                    if event.button == 4:
                        path_target = clamp_scroll(path_target + 80, selected_game["id"])
                    elif event.button == 5:
                        path_target = clamp_scroll(path_target - 80, selected_game["id"])

        update(now)
        draw(now)
        apply_shake()
        pygame.display.flip()

        await asyncio.sleep(0)  # Отдаем управление браузеру

    save_progress(progress)
    pygame.quit()


if __name__ == '__main__':
    asyncio.run(main())
